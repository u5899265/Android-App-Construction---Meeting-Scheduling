# Team structure and roles

## Roles
1. Zheng Huang: team leader
2. Yuchen Zhang: visual designer
3. Zihang Wei: facilitator
4. Danhui Zhang: member

## Task allocation
1. Zheng Huang: design data structure, firebase server
2. Yuchen Zhang: activities involving calendar operations
3. Zihang Wei: email functions and confirmation activity, worked on push notification
4. Danhui Zhang: new meeting activity
