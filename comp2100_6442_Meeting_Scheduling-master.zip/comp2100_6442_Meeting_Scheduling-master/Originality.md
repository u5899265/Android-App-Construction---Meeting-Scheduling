# Statements of originality
This file outlines others' codes that we have utilised or adapted.
---

1. Author: Android Developers website
- Usage: CreateMeetingActivity.composeEmail(), ConfirmMeetingActivity.composeEmail()
- url: https://developer.android.com/guide/components/intents-common#java
---
2. Author: Raquib-ul-Alam Kanak
- Usage: DatetimeInterpreter Interface, WeekView, WeekViewEvent, BaseActivity
- url: https://github.com/alamkanak/Android-Week-View
---
3. Author: Jesse
- Usage: WeekViewUtil
- url: 
---
4. Author: Ted Hopp
- Usage: NotificationID
- url: https://stackoverflow.com/questions/25713157/generate-int-unique-id-as-android-notification-id
