package com.example.comp2100_6442_meeting_scheduling.NetworkOperation;

public class FetchByOwner {
    // User user = Read.getLocalUser()
}
