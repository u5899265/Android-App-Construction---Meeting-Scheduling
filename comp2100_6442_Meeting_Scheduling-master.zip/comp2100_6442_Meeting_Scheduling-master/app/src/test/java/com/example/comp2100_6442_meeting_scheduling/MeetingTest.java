package com.example.comp2100_6442_meeting_scheduling;

import com.example.comp2100_6442_meeting_scheduling.Data.Meeting;
import com.example.comp2100_6442_meeting_scheduling.Data.User;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;


public class MeetingTest {

    User owner = new User("chenchen", "chenchen@gmail.com", 5899265);
    User participant_1 = new User("Toolman1", "111222@gmail.com", 5115);
    User participant_2 = new User("Toolman2", "112233@gmail.com", 1551);
    User participant_3 = new User("Toolman3", "123456@gmail.com", 233);
    List<User> participants = new LinkedList<>();
    LocalDateTime deadline = LocalDateTime.of(2020, 5, 22, 0, 23, 43);
    LocalDateTime startingTime1 = LocalDateTime.of(2020, 5, 22, 20, 20, 55);
    LocalDateTime startingTime2 = LocalDateTime.of(2020, 5, 23, 20, 21, 56);

    // Test the participants are successfully recorded in the new meeting.
    @Test
    public void participantsListTest() {
        participants.add(participant_1);
        participants.add(participant_2);
        participants.add(participant_3);
        Meeting meeting1 = new Meeting(Duration.ofMinutes(15), "Meeting 1", "AI",
                "The meeting is about AI research topics.", owner, participants, deadline,
                startingTime1);

        assert(meeting1.getParticipants().get(0) != null);
        assert(meeting1.getParticipants().get(1) != null);
        assert(meeting1.getParticipants().get(2) != null);
    }

    // Test the startingTimes are successfully recorded in the new meeting.
    @Test
    public void startingTimesTest() {
        Meeting meeting2 = new Meeting(Duration.ofMinutes(15), "Meeting 2", "AI",
                "The meeting is about AI research topics.", owner, participants, deadline, startingTime1, startingTime2);
        assert(meeting2.getStartingTimes().get(0) != null);
        assert(meeting2.getStartingTimes().get(1) != null);
    }

    @Test
    public void otherParametersTest() {
        Meeting meeting1 = new Meeting(Duration.ofMinutes(15), "Meeting 1", "AI",
                "The meeting is about AI research topics.", owner, participants, deadline,
                startingTime1);
        Meeting meeting2 = new Meeting(Duration.ofMinutes(15), "Meeting 2", "AI",
                "The meeting is about AI research topics.", owner, participants, deadline, startingTime1, startingTime2);
        assertEquals(meeting1.getDuration(), meeting2.getDuration());
        assertEquals(meeting1.getTag(), meeting2.getTag());
        assertEquals(meeting1.getOwner(), meeting2.getOwner());
        assertEquals(meeting1.getDescription(), meeting2.getDescription());
        assertEquals(meeting1.getDeadline(), meeting2.getDeadline());
    }
}
