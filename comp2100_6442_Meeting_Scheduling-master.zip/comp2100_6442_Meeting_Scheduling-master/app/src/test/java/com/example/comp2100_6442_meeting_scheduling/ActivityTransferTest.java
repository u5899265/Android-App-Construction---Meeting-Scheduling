package com.example.comp2100_6442_meeting_scheduling;

import android.content.Intent;
import android.os.Build;

import androidx.appcompat.app.AppCompatActivity;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;

import static org.junit.Assert.assertEquals;
import static org.robolectric.Shadows.shadowOf;


@Config(sdk = {Build.VERSION_CODES.O_MR1})
@RunWith(RobolectricTestRunner.class)
public class ActivityTransferTest {

    // When CreateNew floatingButton in CalendarActivity is clicked, user should go to CreateMeetingActivity.
    @Test
    public void clickAddNew_startMainActivity() {
        AppCompatActivity activity = Robolectric.setupActivity(CalendarActivity.class);
        activity.findViewById(R.id.floatingActionButton).performClick();

        Intent expectedIntent = new Intent(activity, CreateMeetingActivity.class);
        Intent actual = shadowOf(RuntimeEnvironment.application).getNextStartedActivity();
        assertEquals(expectedIntent.getComponent(), actual.getComponent());
    }

    // When MyMeetings floatingButton in CalendarActivity is clicked, user should go to MyMeetingsActivity.
    @Test
    public void clickMyMeeting_startMyMeetingsActivity() {
        AppCompatActivity activity = Robolectric.setupActivity(CalendarActivity.class);
        activity.findViewById(R.id.floatingActionButton2).performClick();
        
        Intent expectedIntent = new Intent(activity, MyMeetingsActivity.class); // MyMeetingsActivity
        Intent actual = shadowOf(RuntimeEnvironment.application).getNextStartedActivity();
        assertEquals(expectedIntent.getComponent(), actual.getComponent());
    }

    // When TESTSELECTION button in MainActivity is clicked, user should go to SelectionActivity.
    @Test
    public void clickSelection_startMainActivity() {
        AppCompatActivity activity = Robolectric.setupActivity(MainActivity.class);
        activity.findViewById(R.id.selection).performClick();

        Intent expectedIntent = new Intent(activity, SelectionActivity.class);
        Intent actual = shadowOf(RuntimeEnvironment.application).getNextStartedActivity();
        assertEquals(expectedIntent.getComponent(), actual.getComponent());
    }
}
